package view;

import controller.CassinoController;

public class CassinoView {
	public static void main(String args[]) {
		CassinoController cc = new CassinoController();
		cc.run();
	}
}
